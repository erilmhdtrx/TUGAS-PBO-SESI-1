package tugas.pbo;

public class SESI1PENGENALANKONSEPPBO {
    public static void main(String[] args) {
        System.out.println("Belajar JAVA");
        System.out.println("Sangat Mudah Sekali");
        System.out.println("dan sangat menyenangkan");
    }
    
}